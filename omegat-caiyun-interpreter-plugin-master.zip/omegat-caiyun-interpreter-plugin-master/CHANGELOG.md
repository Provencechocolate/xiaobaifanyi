# Change Log
All notable changes to this project will be documented in this file.

## [Unreleased]

### Add
- foo
- boo

### Changed

### Fixed

[Unreleased]: https://github.com/miurahr/omegat-plugin-skelton/compare/v0.1...HEAD
